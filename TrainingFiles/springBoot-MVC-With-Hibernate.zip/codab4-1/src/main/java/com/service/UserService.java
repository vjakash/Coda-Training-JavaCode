package com.service;

import com.model.User;

public interface UserService {
	public void createUser(User user);
}
