package com.dao;

import com.model.User;

public abstract class UserDAO {
	public abstract void createUser(com.model.User user);
}
