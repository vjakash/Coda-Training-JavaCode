package injectionpack;

public class MyException extends Exception{

}
