package com.dao;

import com.model.LoginForm;


public interface UserDAO {
	public void createUser(LoginForm user);
}
