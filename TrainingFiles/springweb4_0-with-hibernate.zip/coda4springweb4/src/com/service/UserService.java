package com.service;

import com.model.LoginForm;

public interface UserService {
	public void createUser(LoginForm user);
}
