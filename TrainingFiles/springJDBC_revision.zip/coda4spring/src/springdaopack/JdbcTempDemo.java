package springdaopack;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JdbcTempDemo {
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("config2.xml");
		
		JdbcTest jdbcTest=ctx.getBean("jdbcTest",JdbcTest.class);
		
		jdbcTest.doBusiness2();
		
		
		
	}
}
