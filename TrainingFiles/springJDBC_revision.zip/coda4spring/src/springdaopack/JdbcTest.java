package springdaopack;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

public class JdbcTest {

		private DataSource dataSource;

		public final DataSource getDataSource() {
			return dataSource;
		}

		public final void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
		}
		
		public void doBusiness() {
			JdbcTemplate jdbcTemplate=new JdbcTemplate(dataSource);
			System.out.println(jdbcTemplate);
			
			int count=jdbcTemplate.queryForInt("select count(*) from users");
			
			System.out.println("No of rows in user table...:"+count);
			
			
			String name=jdbcTemplate.queryForObject("select uname from users where uid=1", String.class);
			
			System.out.println("The name of uid 1 is...:"+name);
			
			String name2=jdbcTemplate.queryForObject("select uname from users where uid=?",new Object[] {2}, String.class);
			
			System.out.println("The name of uid 2 is...:"+name2);
			
			Users user=jdbcTemplate.queryForObject("select * from users where uid=?",new Object[] {3}, new MyRowMapper());
			
			System.out.println(user);
			
			List<Users> allUsers=jdbcTemplate.query("select * from users",new MyRowMapperAll() );
			
			System.out.println(allUsers);
		}
		
		public void doBusiness2() {
			NamedParameterJdbcTemplate npjt=new NamedParameterJdbcTemplate(dataSource);
			
			SqlParameterSource myidparam=new MapSqlParameterSource("myid",3);
			Users user=npjt.queryForObject("select * from users where uid=:myid", myidparam,new MyRowMapper());
			
			System.out.println(user);
		}
}

class MyRowMapperAll implements RowMapper<Users>{
	@Override
	public Users mapRow(ResultSet rs, int arg1) throws SQLException {
		Users user=new Users();
		user.setUid(rs.getInt(1));
		user.setUname(rs.getString(2));
		user.setUpass(rs.getString(3));
		user.setFlag(rs.getInt(4));
		return user;
	}
}

class MyRowMapper implements RowMapper<Users>{
	@Override
	public Users mapRow(ResultSet rs, int arg1) throws SQLException {
		Users user=new Users();
		user.setUid(rs.getInt(1));
		user.setUname(rs.getString(2));
		user.setUpass(rs.getString(3));
		user.setFlag(rs.getInt(4));
		return user;
	}
}

class Users{
	private int uid,flag;
	private String uname,upass;
	public final int getUid() {
		return uid;
	}
	public final void setUid(int uid) {
		this.uid = uid;
	}
	public final int getFlag() {
		return flag;
	}
	public final void setFlag(int flag) {
		this.flag = flag;
	}
	public final String getUname() {
		return uname;
	}
	public final void setUname(String uname) {
		this.uname = uname;
	}
	public final String getUpass() {
		return upass;
	}
	public final void setUpass(String upass) {
		this.upass = upass;
	}
	@Override
	public String toString() {
		return "Users [uid=" + uid + ", flag=" + flag + ", uname=" + uname + ", upass=" + upass + "]";
	}
	
}
