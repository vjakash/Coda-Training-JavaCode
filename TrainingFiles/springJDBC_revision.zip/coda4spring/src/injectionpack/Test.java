package injectionpack;

import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

interface TestInterface{
	public void business(MyParam param);
	public void testMethod();
}

public class Test implements TestInterface{
	List<String> mylist;
	
	public final List<String> getMylist() {
		return mylist;
	}

	public final void setMylist(List<String> mylist) {
		this.mylist = mylist;
	}

	public Test() {
		System.out.println("test object created....");
	}
	
	public Test(SubTest subTest,int v) {
		System.out.println("test object with int param created....");
		this.subTest=subTest;
	}
	public Test(SubTest subTest,String s) {
		System.out.println("test object with string param created....");
		this.subTest=subTest;
	}
	private SubTest subTest;

	public SubTest getSubTest() {
		return subTest;
	}

	public void setSubTest(SubTest subTest) {
		System.out.println("setter method called...");
		this.subTest = subTest;
	}
	
	public void business(MyParam myparam) {
		System.out.println(mylist);
		
		subTest.test(myparam);
	}
	@Override
	public void testMethod() {
		System.out.println("test method called........of test class..............");
	}
	public void init() {
		System.out.println("init method called....");
	}
	public void destroy() {
		System.out.println("destroy method called....");
	}
}
class MyParam{
	
}

class SubTest{
	
	public SubTest() {
		System.out.println("sub text object created......");
	}
	public void test(MyParam myparam) {
		System.out.println("test method called...."+myparam);
	}
}

class MyPostProcessor implements BeanPostProcessor{

	@Override
	public Object postProcessAfterInitialization(Object bean, String name) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("post process after init called..."+name);
		return bean;
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String name) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("post process before init called....:"+name);
		return bean;
	}
	
}