package injectionpack;

import org.springframework.aop.ThrowsAdvice;

public class ExceptionAdvice implements ThrowsAdvice{
	public void afterThrowing(MyException my) {
		System.out.println("Exceptiono handling code is written here.....");
	}
}
