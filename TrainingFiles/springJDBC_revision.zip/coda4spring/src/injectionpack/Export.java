package injectionpack;

public interface Export {
	public void doExport();
}
