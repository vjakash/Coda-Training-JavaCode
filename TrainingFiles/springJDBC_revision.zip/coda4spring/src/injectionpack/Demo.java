package injectionpack;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo {
	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("config.xml");
		
		TestInterface test=ctx.getBean("advisedTest",TestInterface.class);
		
		MyParam myparam=new MyParam();
		
		test.business(myparam);
		test.testMethod();
		
		Export export=(Export)test;
		
		export.doExport();
		ctx.close();
	}
}
