package injectionpack;

import java.util.Vector;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class AroundAdvice implements MethodInterceptor{
	Vector<MyParam> v=new Vector<>();
@Override
public Object invoke(MethodInvocation mi) throws Throwable {
	// TODO Auto-generated method stub
	MyParam myparam=(MyParam)mi.getArguments()[0];
	if(v.contains(myparam)) {
		throw new MyException();
	}
	else {
		v.add(myparam);
	}
	System.out.println("around advice is called.....");
	
	
	Object o=mi.proceed();
	return o;
}
}
