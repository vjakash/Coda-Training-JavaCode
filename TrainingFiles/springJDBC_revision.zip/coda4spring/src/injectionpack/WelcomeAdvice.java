package injectionpack;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;


public class WelcomeAdvice implements MethodBeforeAdvice {
@Override
public void before(Method method, Object[] params, Object bean) throws Throwable {
	
	// TODO Auto-generated method stub
	MyParam myp=(MyParam)params[0];
	
	System.out.println(myp);
	
	System.out.println("Welcome...........");
}
}
